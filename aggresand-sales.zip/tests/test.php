<?php
echo password_hash("mothers123", PASSWORD_DEFAULT);
?>