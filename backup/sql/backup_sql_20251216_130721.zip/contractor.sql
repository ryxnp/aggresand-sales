INSERT INTO `contractor` (`contractor_id`,`contractor_name`,`contact_person`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('1','TestName','ContactPerson','ContactNo','TestContractor@gmail.com','Active','1','2025-11-26 14:26:09','2025-11-26 14:29:32','1','1');
INSERT INTO `contractor` (`contractor_id`,`contractor_name`,`contact_person`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('2','Contractor#2','Weng','09871262782','Weng@gmail.com','Active','0','2025-11-26 14:29:27','2025-11-26 23:56:51','1','1');
INSERT INTO `contractor` (`contractor_id`,`contractor_name`,`contact_person`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('3','asdkjaskdjh','aksjdhakjshd','akjshdkajhsd','akjshdkajshd@gmail.com','Active','1','2025-11-26 14:30:33','2025-11-26 14:30:49','1','1');
INSERT INTO `contractor` (`contractor_id`,`contractor_name`,`contact_person`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('4','Contractor#4','John','09761238614','John@gmail.com','Active','0','2025-11-26 20:18:11','2025-11-26 23:56:30','1','1');
INSERT INTO `contractor` (`contractor_id`,`contractor_name`,`contact_person`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('5','Contractor#5','Billy','09769987612','Billy@gmail.com','Active','0','2025-11-26 20:18:28','2025-11-26 23:56:12','1','1');
INSERT INTO `contractor` (`contractor_id`,`contractor_name`,`contact_person`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('6','Contractor#6','Ron Jacob','096237431','Ron@gmail.com','Active','0','2025-11-27 01:48:51','2025-11-27 01:48:51','1','1');
INSERT INTO `contractor` (`contractor_id`,`contractor_name`,`contact_person`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('7','Test Contractor','Test Contractor','09763303167','TestContractor@gmail.com','Active','0','2025-12-01 10:18:17','2025-12-01 10:18:17','1','1');
INSERT INTO `contractor` (`contractor_id`,`contractor_name`,`contact_person`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('8','JRS Hauling Services','Juan Dela Cruz','09170000001','jrs@haul.com','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `contractor` (`contractor_id`,`contractor_name`,`contact_person`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('9','Triple A Trucking','Ana Santos','09170000002','aaa@truck.com','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `contractor` (`contractor_id`,`contractor_name`,`contact_person`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('10','Metro Haulers Inc','Pedro Gomez','09170000003','metro@haul.com','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `contractor` (`contractor_id`,`contractor_name`,`contact_person`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('11','Northside Aggregates','Mark Reyes','09170000004','northside@agg.com','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `contractor` (`contractor_id`,`contractor_name`,`contact_person`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('12','South Haulers Logistics','Lisa Cruz','09170000005','south@haul.com','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
