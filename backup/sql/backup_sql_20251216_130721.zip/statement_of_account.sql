INSERT INTO `statement_of_account` (`soa_id`,`soa_no`,`company_id`,`site_id`,`terms`,`status`,`is_deleted`,`created_by`,`edited_by`,`date_created`,`date_edited`,`date_finalized`)
                     VALUES ('1','SOA-2025-0001','3','1','30 Days','finalized','0','1','1','2025-12-15 12:04:17','2025-12-15 20:47:41','');
INSERT INTO `statement_of_account` (`soa_id`,`soa_no`,`company_id`,`site_id`,`terms`,`status`,`is_deleted`,`created_by`,`edited_by`,`date_created`,`date_edited`,`date_finalized`)
                     VALUES ('2','SOA-2025-0002','2','7','15 Days','draft','0','1','','2025-12-15 12:04:17','','');
INSERT INTO `statement_of_account` (`soa_id`,`soa_no`,`company_id`,`site_id`,`terms`,`status`,`is_deleted`,`created_by`,`edited_by`,`date_created`,`date_edited`,`date_finalized`)
                     VALUES ('3','SOA-2025-0003','4','10','15 Days','finalized','0','1','1','2025-12-15 19:48:07','2025-12-15 21:22:25','');
INSERT INTO `statement_of_account` (`soa_id`,`soa_no`,`company_id`,`site_id`,`terms`,`status`,`is_deleted`,`created_by`,`edited_by`,`date_created`,`date_edited`,`date_finalized`)
                     VALUES ('4','SOA-2025-0004','1','3','15','draft','0','1','1','2025-12-15 21:30:17','2025-12-15 21:30:17','');
