INSERT INTO `site` (`site_id`,`site_name`,`remarks`,`location`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('1','Nangka','****','Marikina City','Active','0','2025-11-26 20:58:40','2025-11-26 23:57:51','1','1');
INSERT INTO `site` (`site_id`,`site_name`,`remarks`,`location`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('2','Nangka','***','Marikina City','Active','0','2025-11-26 23:58:06','2025-11-26 23:58:06','1','1');
INSERT INTO `site` (`site_id`,`site_name`,`remarks`,`location`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('3','City Hall','Small Shop','Quezon City','Active','0','2025-11-26 23:58:33','2025-11-26 23:58:33','1','1');
INSERT INTO `site` (`site_id`,`site_name`,`remarks`,`location`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('4','City Hall','Large Shop','Quezon City','Active','0','2025-11-26 23:58:41','2025-11-26 23:58:41','1','1');
INSERT INTO `site` (`site_id`,`site_name`,`remarks`,`location`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('5','Ever Gotesco','D.I.Y Store','Commonwealth','Active','0','2025-11-26 23:59:09','2025-11-26 23:59:09','1','1');
INSERT INTO `site` (`site_id`,`site_name`,`remarks`,`location`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('6','Ever Gotesco','Mercury Drug','Commonwealth','Active','0','2025-11-26 23:59:22','2025-11-26 23:59:22','1','1');
INSERT INTO `site` (`site_id`,`site_name`,`remarks`,`location`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('7','Batulao Site','Nasugbu Project','Batangas','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `site` (`site_id`,`site_name`,`remarks`,`location`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('8','Nangka Site','Cainta Project','Rizal','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `site` (`site_id`,`site_name`,`remarks`,`location`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('9','Cabuyao Plant','Laguna Project','Laguna','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `site` (`site_id`,`site_name`,`remarks`,`location`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('10','Porac Quarry','Main Extraction Area','Pampanga','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `site` (`site_id`,`site_name`,`remarks`,`location`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('11','Calamba Site','Warehouse Build','Laguna','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
