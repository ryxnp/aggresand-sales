INSERT INTO `company` (`company_id`,`company_name`,`address`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('1','Company 1','Company 1 Address','09123456789','Company1@gmail.com','Active','0','2025-11-26 14:31:46','2025-11-27 00:03:05','1','1');
INSERT INTO `company` (`company_id`,`company_name`,`address`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('2','Company 2','Company 2 Address','09123456789','Company2@gmail.com','Active','0','2025-11-26 18:24:21','2025-11-27 00:02:50','1','1');
INSERT INTO `company` (`company_id`,`company_name`,`address`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('3','Company 3','Company 3 Address','09123456789','Company1@gmail.com','Active','0','2025-11-26 18:25:57','2025-11-27 00:02:33','1','1');
INSERT INTO `company` (`company_id`,`company_name`,`address`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('4','Aggresand Quarrying Inc.','Bacolor, Pampanga','09171234567','info@aggresand.com','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `company` (`company_id`,`company_name`,`address`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('5','Alphasand Aggregates Trading','Ortigas Center, Pasig','09181234567','office@alphasand.com','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `company` (`company_id`,`company_name`,`address`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('6','Megawide Construction Corp','Quezon City','09172223333','megawide@gmail.com','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `company` (`company_id`,`company_name`,`address`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('7','Unicon Ready Mix','Caloocan City','09179998888','unicon@gmail.com','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `company` (`company_id`,`company_name`,`address`,`contact_no`,`email`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('8','PrimeBuilders Corp','Makati City','09175556666','contact@primebuilders.com','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
