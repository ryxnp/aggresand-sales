INSERT INTO `customer` (`customer_id`,`company_id`,`contractor_id`,`site_id`,`customer_name`,`contact_no`,`email`,`address`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('1','3','5','1','Ryan Paul','09763303167','rodanillaryan@gmail.com','Quezon City','Active','0','2025-11-26 23:00:33','2025-11-26 23:00:33','1','1');
INSERT INTO `customer` (`customer_id`,`company_id`,`contractor_id`,`site_id`,`customer_name`,`contact_no`,`email`,`address`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('2','1','4','3','Test Customer','09763303167','tetst@gmail.com','Quezon City','Active','0','2025-11-27 00:33:29','2025-11-27 00:33:29','1','1');
INSERT INTO `customer` (`customer_id`,`company_id`,`contractor_id`,`site_id`,`customer_name`,`contact_no`,`email`,`address`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('3','1','1','1','4GC-ARJILL CONCRETE BATCHING PLANT','09175551234','4gc@batch.com','Calamba, Laguna','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `customer` (`customer_id`,`company_id`,`contractor_id`,`site_id`,`customer_name`,`contact_no`,`email`,`address`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('4','2','2','2','Nangka Ready Mix','09176661234','nangka@mix.com','Cainta, Rizal','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `customer` (`customer_id`,`company_id`,`contractor_id`,`site_id`,`customer_name`,`contact_no`,`email`,`address`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('5','3','3','3','MetroMix Laguna','09178881234','metromix@laguna.com','Cabuyao, Laguna','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `customer` (`customer_id`,`company_id`,`contractor_id`,`site_id`,`customer_name`,`contact_no`,`email`,`address`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('6','4','4','4','Unicon Project Pampanga','09179991234','unicon@pampanga.com','Porac, Pampanga','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `customer` (`customer_id`,`company_id`,`contractor_id`,`site_id`,`customer_name`,`contact_no`,`email`,`address`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('7','5','5','5','PrimeBuilders South','09174441234','pbs@south.com','Calamba, Laguna','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `customer` (`customer_id`,`company_id`,`contractor_id`,`site_id`,`customer_name`,`contact_no`,`email`,`address`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('8','1','2','3','Aggresand Major Client A','09175559999','clientA@agg.com','Quezon City','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `customer` (`customer_id`,`company_id`,`contractor_id`,`site_id`,`customer_name`,`contact_no`,`email`,`address`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('9','2','1','4','Alphasand Bulk Buyer B','09176669999','buyerB@alpha.com','Mandaluyong','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `customer` (`customer_id`,`company_id`,`contractor_id`,`site_id`,`customer_name`,`contact_no`,`email`,`address`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('10','3','5','1','Megawide Supplier Client C','09178889999','clientC@mega.com','Pasig','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `customer` (`customer_id`,`company_id`,`contractor_id`,`site_id`,`customer_name`,`contact_no`,`email`,`address`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('11','4','3','2','Unicon Cement Buyer D','09179994444','buyerD@unicon.com','Caloocan','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `customer` (`customer_id`,`company_id`,`contractor_id`,`site_id`,`customer_name`,`contact_no`,`email`,`address`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('12','5','4','5','PrimeBuilders Bulk Client E','09174445555','clientE@prime.com','Makati','Active','0','2025-12-09 18:55:35','2025-12-09 18:55:35','1','1');
INSERT INTO `customer` (`customer_id`,`company_id`,`contractor_id`,`site_id`,`customer_name`,`contact_no`,`email`,`address`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('13','1','7','10','New Customer','09123456789','new@gmail.com','QC','Active','0','2025-12-15 17:51:33','2025-12-15 17:51:33','1','1');
INSERT INTO `customer` (`customer_id`,`company_id`,`contractor_id`,`site_id`,`customer_name`,`contact_no`,`email`,`address`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('14','4','11','10','SOA 3 Customer','09763303167','SOA3@gmail.com','QC','Active','0','2025-12-15 21:21:54','2025-12-15 21:21:54','1','1');
