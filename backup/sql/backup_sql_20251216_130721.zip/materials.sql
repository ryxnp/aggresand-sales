INSERT INTO `materials` (`material_id`,`material_name`,`unit_price`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('1','Glass','100.00','active','0','2025-11-26 22:59:34','2025-11-26 22:59:34','1','1');
INSERT INTO `materials` (`material_id`,`material_name`,`unit_price`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('2','Sand','250.00','active','0','2025-11-26 22:59:40','2025-11-26 22:59:40','1','1');
INSERT INTO `materials` (`material_id`,`material_name`,`unit_price`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('3','Dirt','100.00','active','0','2025-11-26 22:59:49','2025-11-26 22:59:49','1','1');
INSERT INTO `materials` (`material_id`,`material_name`,`unit_price`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('4','Tiles','162.00','active','0','2025-11-27 00:00:22','2025-11-27 00:00:22','1','1');
INSERT INTO `materials` (`material_id`,`material_name`,`unit_price`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('5','Bricks','612.00','active','0','2025-11-27 00:00:29','2025-11-27 00:00:29','1','1');
INSERT INTO `materials` (`material_id`,`material_name`,`unit_price`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('6','Gravel','215.00','active','0','2025-11-27 00:00:40','2025-11-27 00:00:40','1','1');
INSERT INTO `materials` (`material_id`,`material_name`,`unit_price`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('7','Sand A','51.00','active','0','2025-12-01 10:21:37','2025-12-01 10:21:37','1','1');
INSERT INTO `materials` (`material_id`,`material_name`,`unit_price`,`status`,`is_deleted`,`date_created`,`date_edited`,`created_by`,`edited_by`)
                     VALUES ('8','Remi','0.00','active','0','2025-12-15 21:32:33','2025-12-15 21:32:33','1','1');
